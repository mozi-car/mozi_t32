@echo off

set BIN_FILE_1=CORTEXM_S32G399_car_sw.bin
set BIN_FILE_2=CORTEXM_S32G399_hpe_boot.blob
set BIN_FILE_3=llce_fw.bin

copy \\hid4262w\Workspace\git_projects\xmi_ivs\car_s32g\car_sw\output\bin\%BIN_FILE_1% D:\FlashImages\cgj /y
copy \\hid4262w\Workspace\git_projects\xmi_ivs\bootloader_s32g\hpe_boot\output\bin\%BIN_FILE_2% D:\FlashImages\cgj /y
copy \\hid4262w\Workspace\git_projects\xmi_ivs\bootloader_s32g\hpe_boot\output\bin\%BIN_FILE_3% D:\FlashImages\cgj /y
